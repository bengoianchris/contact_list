import React, { useEffect, useState } from 'react';
import './App.css';
import { Alert } from '@mui/material';
import Login from './pages/authentication/login';
import ContactList from './pages/phonebook/contactList';

const App = () => {
  const [users, setUsers] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [activeUser, setActiveUser] = useState({});
  const [invalidLogin, setInvalidLogin] = useState(false);
  const [userAlreadyExists, setUserAlreadyExists] = useState(false);
  const [contactAlreadyExists, setContactAlreadyExists] = useState(false);
  const [userRegistered, setUserRegistered] = useState(false);
  const [myContacts, setMyContacts] = useState([]);

  const registerUser = (registeredUser) => {
    let userArr = [...users];
    let existingUserArr = userArr.filter((user) => {
      return user.userName === registeredUser.userName
    })
    if (existingUserArr.length === 0) {
      userArr.push(registeredUser);
      setUserAlreadyExists(false);
      setUserRegistered(true);
      setUsers(userArr)
    } else {
      setUserAlreadyExists(true);
    }
  }

  useEffect(() => {
    if (userAlreadyExists === true) {
      setTimeout(() => {
        setUserAlreadyExists(false)
      }, 3000);
    }
  }, [userAlreadyExists])

  useEffect(() => {
    if (userRegistered === true) {
      setTimeout(() => {
        setUserRegistered(false)
      }, 3000);
    }
  }, [userAlreadyExists])

  useEffect(() => {
    if (contactAlreadyExists === true) {
      setTimeout(() => {
        setContactAlreadyExists(false)
      }, 3000);
    }
  }, [contactAlreadyExists])

  useEffect(() => {
    if (invalidLogin === true) {
      setTimeout(() => {
        setInvalidLogin(false)
      }, 3000);
    }
  }, [invalidLogin])

  const loginUser = (credentials) => {
    let searchedUser = {}
    users.map((user) => {
      if (user.userName === credentials.userName) {
        searchedUser = { ...user }
      }
    })
    if (Object.keys(searchedUser).length > 0) {
      if (searchedUser.password === credentials.password) {
        setInvalidLogin(false)
        setActiveUser(searchedUser)
        let contactArr = [...contacts];
        let myExistingContactArr = contactArr.filter((contact) => {
          return contact.userName === credentials.userName
        })
        setMyContacts(myExistingContactArr)
      } else {
        setInvalidLogin(true)
      }
    } else {
      setInvalidLogin(true)
    }
  }

  const addContact = (registeredContact) => {
    let contactArr = [...contacts];
    let existingContactArr = contactArr.filter((contact) => {
      return contact.contact === registeredContact.contact
    })
    let myExistingContactArr = contactArr.filter((contact) => {
      return contact.userName === registeredContact.userName
    })
    if (existingContactArr.length === 0) {
      contactArr.push(registeredContact);
      myExistingContactArr.push(registeredContact);
      setContactAlreadyExists(false);
      setContacts(contactArr)
      setMyContacts(myExistingContactArr)
    } else {
      setContactAlreadyExists(true);
    }
  }

  return (
    <div className="App">
      {invalidLogin ? (
        <Alert severity="error" onClose={() => { setInvalidLogin(false) }} >
          Invalid Username or Password. Please check credentials and try again!!
        </Alert>) : null
      }
      {contactAlreadyExists ? (
        <Alert severity="error" onClose={() => { setContactAlreadyExists(false) }} >
          Contact Already Exists!!
        </Alert>) : null
      }
      {userAlreadyExists ? (
        <Alert severity="error" onClose={() => { setUserAlreadyExists(false) }} >
          User Already Registered. Please Login to Continue!!
        </Alert>) : null
      }
      {userRegistered ? (
        <Alert severity="success" onClose={() => { setUserRegistered(false) }} >
          User Successfully Registered. Please proceed to Login!!
        </Alert>) : null
      }

      <header className="App-header">
        {Object.keys(activeUser).length > 0 ? <ContactList addContact={addContact} activeUser={activeUser} myContacts={myContacts} /> : <Login loginUser={loginUser} registerUser={registerUser} />}
      </header>
    </div>
  );
}

export default App;
