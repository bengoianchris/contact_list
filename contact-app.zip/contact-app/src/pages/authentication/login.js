import React, { useEffect, useState } from "react";
import { TextField, Card } from "@mui/material"
import Register from "./register";

const Login = ({ loginUser, registerUser }) => {
  const [registerPage, setRegisterPage] = useState(false);
  const [userName, setUserName] = useState('');
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState(true);
  const [userNameError, setUserNameError] = useState(true);
  const [formValid, setFormValid] = useState(false);
  const login = () => {
    loginUser({
      userName: userName,
      password: password
    })
  }
  useEffect(() => {
    let errorState = false
    if (userName.length >= 3) {
      setUserNameError(false)
    } else {
      setUserNameError(true)
      errorState = true
    }
    if (password.length >= 3) {
      setPasswordError(false)
    } else {
      setPasswordError(true)
      errorState = true
    }
    if (errorState === false) {
      setFormValid(true)
    }
  }, [userName, password])

  const registerNewUser = (user) => {
    registerUser(user)
  }

  const backToLoginPage = () => {
    setRegisterPage(false);
  }

  return (
    <div className="d-flex justify-content-center align-items-center">
      {!registerPage ? (
        <Card variant="outlined" className="p-3 d-flex flex-column justify-content-center align-items-center">
          <h5>My Contact App</h5>
          <hr />
          <TextField
            className="mb-3"
            size="small"
            error={userNameError}
            fullWidth
            label="Username"
            autoComplete="off"
            variant="outlined"
            onKeyUp={(event) => {
              setUserName(event.target.value);
            }}
            helperText={userNameError ? 'Min 3 characters' : null}
          />
          <TextField
            className="mb-3"
            size="small"
            fullWidth
            error={passwordError}
            label="Password"
            type="password"
            autoComplete="off"
            variant="outlined"
            onKeyUp={(event) => {
              setPassword(event.target.value);
            }}
            helperText={passwordError ? 'Min 3 characters' : null}
          />
          <button className="btn btn-md btn-primary" disabled={!formValid} onClick={() => { login() }}>Login</button>
          <h5 className="my-3">OR</h5>
          <button className="btn btn-md btn-primary" onClick={() => { setRegisterPage(true) }}>Register as New User</button>
        </Card>
      ) : (
        <Register registerNewUser={registerNewUser} backToLoginPage={backToLoginPage} />
      )}
    </div>
  );
}

export default Login;