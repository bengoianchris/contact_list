import React, { useEffect, useState } from "react";
import { TextField, Card, MDBRow, MDBCol } from "@mui/material"

const ContactList = ({ addContact, activeUser, myContacts }) => {
    const [names, setNames] = useState('');
    const [contact, setContact] = useState('');
    const [namesError, setNamesError] = useState(true);
    const [contactError, setContactError] = useState(true);
    const [formValid, setFormValid] = useState(false);
    const saveContact = () => {
        addContact({
            names: names,
            userName: activeUser.userName,
            contact: contact
        })
        setNames('')
        setContact('')
        setNamesError(true)
        setContactError(true)
        setFormValid(false)
    }
    useEffect(() => {
        let errorState = false
        if (names.length >= 3) {
            setNamesError(false)
        } else {
            setNamesError(true)
            errorState = true
        }
        if (contact.length >= 3) {
            setContactError(false)
        } else {
            setContactError(true)
            errorState = true
        }
        if (errorState === false) {
            setFormValid(true)
        }
    }, [names, contact])

    return (
        <div className="" style={{ width: '100%' }}>
            <p>
                Hi <span>{activeUser.names}</span>
            </p>
            <div className="row">
                <div className="col-md-4 col-sm-12">
                    <Card variant="outlined" className="p-3 d-flex flex-column justify-content-center align-items-center">
                        <h5>Register New Contact</h5>
                        <hr />
                        <TextField
                            className="mb-3"
                            size="small"
                            error={namesError}
                            fullWidth
                            label="Names"
                            autoComplete="off"
                            variant="outlined"
                            onKeyUp={(event) => {
                                setNames(event.target.value);
                            }}
                            helperText={namesError ? 'Min 3 characters' : null}
                        />
                        <TextField
                            className="mb-3"
                            size="small"
                            error={contactError}
                            fullWidth
                            label="Phone Contact"
                            autoComplete="off"
                            variant="outlined"
                            onKeyUp={(event) => {
                                setContact(event.target.value);
                            }}
                            helperText={contactError ? 'Min 10 characters' : null}
                        />
                        <button className="btn btn-md btn-primary" disabled={!formValid} onClick={() => { saveContact() }}>Save Contact</button>
                    </Card>
                </div>
                <div className="col-md-8 col-sm-12">
                    <Card variant="outlined" className="p-3 d-flex flex-column justify-content-start align-items-start">
                        <h5>Phone Book</h5>
                        {myContacts.map((contact) => {
                            return (<div className="d-flex flex-column justify-content-start align-items-start">
                                <h5 className="text-left">Name: {contact.names}</h5>
                                <h5>Contact: {contact.contact}</h5>
                                <hr />
                            </div>)
                        })}
                    </Card>
                </div>
            </div>
        </div>
    );
}

export default ContactList;